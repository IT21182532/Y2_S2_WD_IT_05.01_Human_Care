package com.example.sample1;

import android.app.Activity;

public class EmployeeDetailsActivity extends Activity {
}
