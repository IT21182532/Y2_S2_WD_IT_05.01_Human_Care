package com.example.sample1.models

data class EmployeeModel(
    var empId: String? = null,
    var empName: String? = null,
    var Contact: String? = null,
    var empSalary: String? = null,
    var empSalary2: String? = null,
    var address: String? = null
)