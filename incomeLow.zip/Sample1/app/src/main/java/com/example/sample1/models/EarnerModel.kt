package com.example.sample1.models

data class EarnerModel(
    var empId: String? = null,
    var empName: String? = null,
    var Contact: String? = null,
    var address: String? = null,
    var district: String? = null,
    var member: String? = null

)