package com.example.sample1.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.sample1.R

class MyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my)
    }
}