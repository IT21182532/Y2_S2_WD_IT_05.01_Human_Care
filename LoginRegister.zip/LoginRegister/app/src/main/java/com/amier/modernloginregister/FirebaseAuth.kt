package com.amier.modernloginregister

class FirebaseAuth {

}
